// Fill in your AWS Cognito config to enable real authentication.
// Leave as `null` to use local stub auth for development.

// This file is deprecated - using amplify_outputs.json directly
export const AWS_CONFIG = null;

