const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'ap-southeast-2' });
const docClient = DynamoDBDocumentClient.from(client);
const TABLE_NAME = 'NewsArticles';

function normalizeText(text) {
  return text.toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function calculateRelevanceScore(article, keywords) {
  const titleText = normalizeText(article.title || '');
  const descText = normalizeText(article.description || '');
  const summaryText = normalizeText(article.structuredSummary || '');
  const labelsText = normalizeText((article.labels || []).join(' '));
  
  let score = 0;
  
  keywords.forEach(keyword => {
    const keywordNorm = normalizeText(keyword);
    
    // Title matches get highest weight
    if (titleText.includes(keywordNorm)) score += 10;
    
    // Label matches get high weight
    if (labelsText.includes(keywordNorm)) score += 8;
    
    // Summary matches get medium weight
    if (summaryText.includes(keywordNorm)) score += 5;
    
    // Description matches get lower weight
    if (descText.includes(keywordNorm)) score += 3;
    
    // Exact word boundary matches get bonus
    const wordBoundary = new RegExp(`\\b${keywordNorm}\\b`);
    if (wordBoundary.test(titleText)) score += 5;
    if (wordBoundary.test(labelsText)) score += 3;
  });
  
  return score;
}

async function handleSearch(queryParams, headers) {
  const query = (queryParams.q || '').trim();
  const limit = Math.min(parseInt(queryParams.limit || '20'), 50);
  
  if (!query || query.length < 2) {
    return { 
      statusCode: 200, 
      headers, 
      body: JSON.stringify([]) 
    };
  }
  
  console.log('Search query:', query);
  
  const params = {
    TableName: TABLE_NAME,
    FilterExpression: 'attribute_exists(imageUrl) AND imageUrl <> :empty',
    ExpressionAttributeValues: { ':empty': '' }
  };
  
  const result = await docClient.send(new ScanCommand(params));
  const articles = result.Items || [];
  
  const keywords = query.split(/\s+/).filter(k => k.length > 1);
  
  const scoredResults = articles
    .map(article => ({
      article,
      score: calculateRelevanceScore(article, keywords)
    }))
    .filter(item => item.score > 0)
    .sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return new Date(b.article.publishedAt || 0) - new Date(a.article.publishedAt || 0);
    })
    .slice(0, limit);
  
  const searchResults = scoredResults.map(({ article }) => ({
    id: article.article_id,
    title: article.title || 'Untitled',
    url: article.url,
    source: article.source || 'Unknown',
    description: article.structuredSummary || article.description || '',
    imageUrl: article.imageUrl,
    publishedAt: article.publishedAt,
    category: article.category || 'Other',
    region: article.region || 'Global',
    labels: article.labels || []
  }));
  
  console.log(`Found ${searchResults.length} results for "${query}"`);
  
  return {
    statusCode: 200,
    headers,
    body: JSON.stringify(searchResults)
  };
}

async function handleNews(queryParams, headers) {
  const limit = Math.min(parseInt(queryParams.limit || '10'), 50);
  const seen = queryParams.seen ? queryParams.seen.split(',').filter(Boolean) : [];
  
  const params = {
    TableName: TABLE_NAME,
    FilterExpression: 'attribute_exists(imageUrl) AND imageUrl <> :empty',
    ExpressionAttributeValues: { ':empty': '' },
    Limit: Math.min(limit + seen.length, 100)
  };
  
  const result = await docClient.send(new ScanCommand(params));
  
  const articles = (result.Items || [])
    .filter(item => !seen.includes(item.article_id))
    .map(item => ({
      id: item.article_id,
      title: item.title || 'Untitled',
      url: item.url,
      source: item.source || 'Unknown',
      description: item.structuredSummary || item.description || '',
      imageUrl: item.imageUrl,
      publishedAt: item.publishedAt,
      category: item.category || 'Other',
      region: item.region || 'Global',
      labels: item.labels || []
    }))
    .sort((a, b) => new Date(b.publishedAt || 0) - new Date(a.publishedAt || 0))
    .slice(0, limit);
  
  return {
    statusCode: 200,
    headers,
    body: JSON.stringify(articles)
  };
}

exports.handler = async (event) => {
  console.log('Request:', JSON.stringify(event, null, 2));
  
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS'
  };
  
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }
  
  try {
    const queryParams = event.queryStringParameters || {};
    const path = event.path || event.rawPath || '';
    
    if (path.includes('/search')) {
      return await handleSearch(queryParams, headers);
    }
    
    return await handleNews(queryParams, headers);
    
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Internal server error',
        message: error.message
      })
    };
  }
};